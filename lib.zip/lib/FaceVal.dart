// import 'dart:io';

// import 'package:flutter/material.dart';
// import 'package:camera/camera.dart';


// class FaceVal extends StatefulWidget {
//   const FaceVal({super.key});

//   @override
//   // ignore: library_private_types_in_public_api
//   _FaceValState createState() => _FaceValState();
// }

// class _FaceValState extends State<FaceVal> {
//   late CameraController _controller;
//   late Future<void> _initializeControllerFuture;
//   bool _isCameraInitialized = false;

//   @override
//   void initState() {
//     super.initState();
//     _initializeCamera();
//   }

//   Future<void> _initializeCamera() async {
//     // Obtain a list of the available cameras on the device.
//     final cameras = await availableCameras();

//     // Get a specific camera from the list of available cameras.
//     final firstCamera = cameras.first;

//     _controller = CameraController(
//       firstCamera,
//       ResolutionPreset.high,
//     );

//     // Initialize the controller.
//     _initializeControllerFuture = _controller.initialize();

//     // Once the controller is initialized, update the state.
//     _initializeControllerFuture.then((_) {
//       if (!mounted) return;
//       setState(() {
//         _isCameraInitialized = true;
//       });
//     });
//   }

//   @override
//   void dispose() {
//     // Dispose of the controller when the widget is disposed.
//     _controller.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Face Validation'),
//       ),
//       body: Center(
//         child: _isCameraInitialized
//             ? Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Expanded(
//                     child: CameraPreview(_controller),
//                   ),
//                   const SizedBox(height: 20),
//                   ElevatedButton(
//                     onPressed: () async {
//                       try {
//                         // Ensure that the camera is initialized.
//                         await _initializeControllerFuture;

//                         // Attempt to take a picture and get the file `image`
//                         // where it was saved.
//                         final image = await _controller.takePicture();

//                         // If the picture was taken, display it on a new screen.
//                         Navigator.push(
//                           // ignore: use_build_context_synchronously
//                           context,
//                           MaterialPageRoute(
//                             builder: (context) => DisplayPictureScreen(imagePath: image.path),
//                           ),
//                         );
//                       } catch (e) {
//                         print(e);
//                       }
//                     },
//                     child: const Text('Scan'),
//                   ),
//                   const SizedBox(height: 20),
//                 ],
//               )
//             : const CircularProgressIndicator(),
//       ),
//     );
//   }
// }

// class DisplayPictureScreen extends StatelessWidget {
//   final String imagePath;

//   const DisplayPictureScreen({super.key, required this.imagePath});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text('Display Picture')),
//       body: Center(
//         child: Image.file(File(imagePath)),
//       ),
//     );
//   }
// }
